import{a as t}from"../chunks/entry.BhNOKdwp.js";export{t as start};
